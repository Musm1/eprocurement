import React,{useState} from 'react'
import './style.css'
import {Modal, Form, Col, Button, Table, InputGroup,FormControl} from 'react-bootstrap';

import axios from 'axios'


function Repository() {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const [validated, setValidated] = useState(false);
    const [show, setShow] = useState(false);

    const [docname,setdocname] = useState("");
    const [doctype,setdoctype] = useState("");
    const [docexpiry,setdocexpiry] = useState("");
    const [docdes,setdocdes] = useState("");
    const [docfile,setdocfile] = useState("");
    
    const handleClose = () => setShow(false);

    const handleClick = event => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }  
        setValidated(true);
      };
    
    const handleAddNewDocument = () =>{
        setShow(true);
    }

    const handleSubmit = () => {
        if((docname !== "") && (doctype !== "") && (docexpiry !== "") && (docdes !== "") && (docfile !== ""))
        {
            alert("File should be uploaded");
            setLoading(true);     
            setError(null);
            axios.post('http://localhost:4000/profile-img-upload', { key: docfile,location: docfile }).then(response => {window.location.assign("../Navbar/Navbar1");
            setLoading(false);
            }).catch(error => {
              setLoading(false);
              if (error.response.status === 401) setError(error.response.data.message);
              else setError("Something went wrong. Please try again later.");
            });
        }
        else{
            setValidated(true);
            alert("fill all the fields");
        }
    }

    return (
        <div className="contents">
        <div className="topmenu">   
            <Form>
                <Form.Row>
                <Form.Group as={Col} md="5" controlId="formGridState">
                    <Form.Label>Search</Form.Label>
                        <InputGroup className="mb-3">
                            <FormControl
                                placeholder="Document Name ....."
                                aria-label="Document name"
                                aria-describedby="basic-addon2"
                            />
                            <InputGroup.Append>
                                <Button variant="outline-primary">Search</Button>
                            </InputGroup.Append>
                        </InputGroup>
                    </Form.Group>
                    </Form.Row>
                <Form.Row>
                    <Form.Group as={Col} md="10" controlId="formGridState">
                    </Form.Group>
                    <Form.Group as={Col}md="2" controlId="formGridState">
                        <Button variant="secondary" onClick={handleAddNewDocument}>
                            Add New Document
                        </Button>
                    </Form.Group>
                </Form.Row>
            </Form>
        </div>
        <div className="tablediv">
        <Table striped bordered hover>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Document Name</th>
                    <th>Description</th>
                    <th>Date Added</th>
                    <th>Expiry Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>ISO 8001</td>
                    <td>Document</td>
                    <td>20/1/2018</td>
                    <td>20/1/2019</td>
                    <td><a href="#">view</a></td>
                    <td><a href="#">Update</a></td>
                    <td><a href="#">Delete</a></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>DRAP</td>
                    <td>Document</td>
                    <td>12/3/2019</td>
                    <td>20/1/2020</td>
                    <td><a href="#">view</a></td>
                    <td><a href="#">Update</a></td>
                    <td><a href="#">Delete</a></td>
                </tr>
            </tbody>
            </Table>
        </div>      

        <Modal show={show} onHide={handleClose} animation={false}>
          <Modal.Header closeButton>
            <Modal.Title>Add New Document</Modal.Title>
          </Modal.Header>
      
          <Modal.Body>    
            <Form noValidate validated={validated} onSubmit={handleClick}>
                <Form.Row>
                    <Form.Group as={Col} md="6" controlId="validationCustom03">
                        <Form.Control name="DocumentName" type="text" id="DocName" placeholder="Document Name" onChange={(e) =>{setdocname(e.currentTarget.value)}}  required />
                            <Form.Control.Feedback type="invalid">
                              Please Enter Document Name.
                            </Form.Control.Feedback>
                     </Form.Group>
                    <Form.Group as={Col} md="6" controlId="validationCustom03">
                        <Form.Control name="DocumentType" type="text" id="DocType" placeholder="Document Type" onChange={(e) =>{setdoctype(e.currentTarget.value)}} required />
                            <Form.Control.Feedback type="invalid">
                                Please Specify Document Type.
                            </Form.Control.Feedback>
                    </Form.Group>
                </Form.Row>
                <Form.Row>
                    <Form.Group as={Col} md="6" controlId="validationCustom03">
                   
                    <Form.Label>Expiry Date</Form.Label>         
                        <Form.Control name="DocumentExpiry" type="date" id="DocExpiry" placeholder="Expiry Date" onChange={(e) =>{setdocexpiry(e.currentTarget.value)}} required />
                            <Form.Control.Feedback type="invalid">
                              Please Mention Document Expiry.
                            </Form.Control.Feedback>
                    </Form.Group>
                </Form.Row>
                <Form.Row>
                    <Form.Group as={Col} md="12" controlId="validationCustom03">
                        <Form.Control as="textarea" name="DocumentDescription" type="text" id="DocDes" placeholder="Document Description" onChange={(e) =>{setdocdes(e.currentTarget.value)}} required />
                            <Form.Control.Feedback type="invalid">
                              Please Add Short Description of Document.
                            </Form.Control.Feedback>
                    </Form.Group>
                </Form.Row>
                <Form.Row>
                    <Form.Group as={Col} md="12" controlId="validationCustom03">
                        <input type="file" id="Document" className="browsefile" name="DocumentAdded" onChange={(e) =>{setdocfile(e.currentTarget.value)}} required/> 
                           <Form.Control.Feedback type="invalid">
                                Choose File.
                            </Form.Control.Feedback>
                    </Form.Group>
                </Form.Row>
                <Form.Row>
                <Form.Group as={Col} md="4">
                    <Button variant="secondary" onClick={handleClose}>
                        Cancel
                    </Button>
                </Form.Group>

                <Form.Group as={Col} md="4">
                    <Button variant="success" onClick={handleSubmit}>
                        Save
                    </Button>
                </Form.Group>
              </Form.Row>
            </Form>           
          </Modal.Body>
            
          <Modal.Footer>
          </Modal.Footer>
        </Modal>


    </div>
    )
}

export default Repository;