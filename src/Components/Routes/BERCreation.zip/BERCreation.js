import React, { useState } from 'react'
import './style.css';
import {Form, Col, Button,Badge,Table} from 'react-bootstrap';

function BERCreation() {

    const Companies = [
        { value: 'Abbott'},
        {  value: 'GSK'},
        {  value: 'Sami'},
        {  value: 'Sanofi'} 
      ];

      const Generics = [
        { value: 'Diclofenic Sodium'},
        {  value: 'Ibuprufin'},
        {  value: 'Aspirin'},
        {  value: 'Metrozindole'} 
      ];

      const Records = [
        { id:1, company: 'Abbott', status: 'Manufacturer',remarks: 'Recommended',productgeneric:'Diclofenic Sodium',productdosage:'Tab 200mg',technicalScore:'40'},
        { id:2, company: 'GSK', status: 'Manufacturer',remarks: 'Recommended',productgeneric:'Ibuprufin',productdosage:'Syp 200mg',technicalScore:'45'},
        { id:3, company: 'Sami', status: 'Manufacturer',remarks: 'Not Recommended',productgeneric:'Aspirin',productdosage:'Cap 250mg',technicalScore:'34'},
        { id:4, company: 'Sanofi', status: 'Manufacturer',remarks: 'Recommended',productgeneric:'Metrozindole',productdosage:'Tab 20mg',technicalScore:'45'} 
      ];

      const [show,setshow] = useState(false);
      let getCompany = "";
      let getGeneric = "";  
      const handleCompany = event =>{
       getCompany=event.currentTarget.value;
      };
      
      const handleGenric = event =>{
         getGeneric=event.currentTarget;
      };

      const handleAddRecord = event =>{
        Records.map(r =>{
            if((getCompany == r.company))
            {
                alert("Data in Table are :: "+r.id+" "+r.company+" "+r.status+" "+r.remarks+" " +r.productgeneric+" "+r.productdosage+" "+r.technicalScore+" ")
               return(
                <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Company Name</th>
                        <th>Status</th>
                        <th>Remarks</th>
                        <th>Products Qualified</th>
                        <th>Technical Score</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <tr><td>{r.id}</td><td>{r.company}</td><td>{r.status}</td><td>{r.remarks}</td><td>{r.productgeneric}</td><td>{r.productdosage}</td><td>{r.technicalScore}</td></tr>
                    
                </tbody>
                </Table>
               )
            }
        })
      };
      

    return (
        <div className="contents">
            <div className="Headings">
                <Badge variant="success" style={{ marginLeft:"200px" }}>
                    <h2>Bid Evaluation Report BER</h2>
                </Badge>
                <br/>
                <Form.Row>
                    <Form.Group as={Col}md="3" controlId="formGridState">
                        <Form.Label>Select Company</Form.Label>
                        <Form.Control as="select" onChange={handleCompany}>
                        {Companies.map(o =><option>{o.value}</option>)}
                        </Form.Control>
                    </Form.Group>
                    <Form.Group as={Col}md="3" controlId="formGridState">
                        <Form.Label>Select Generics</Form.Label>
                        <Form.Control as="select" onChange={handleGenric}>
                        {Generics.map(o =><option>{o.value}</option>)}
                        </Form.Control>
                    </Form.Group>

                </Form.Row>

                <Button variant="primary" onClick={handleAddRecord}>
                    Add Record in Report
                </Button>
            </div>
            <div className="tablediv" id="table">
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Company Name</th>
                        <th>Status</th>
                        <th>Remarks</th>
                        <th>Products Qualified</th>
                        <th>Technical Score</th>
                    </tr>
                </thead>
                <tbody>
                    
                    {Records.map(r =><tr><td>{r.id}</td><td>{r.company}</td><td>{r.status}</td><td>{r.remarks}</td><td>{r.productgeneric}</td><td>{r.productdosage}</td><td>{r.technicalScore}</td></tr>)}
                    
                </tbody>
                </Table>
                </div>
        </div>
    )
}

export default BERCreation;
